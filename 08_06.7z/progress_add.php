<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $status = $_POST['status'];
    $notes = $_POST['notes'];
    $id_order = $_POST['id_order'];



    $query = "INSERT INTO public.progress (status, notes, id_order) VALUES ('$status', '$notes', '$id_order')";
    $result = pg_query($conn, $query);
    if ($result) {
        echo "Статус успешно добавлена.";
    } else {
        echo "Ошибка: " . pg_last_error($conn); 
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление статусов</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='progress_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить статус в таблицу</h2>
    <form method="post">
        <label for="status">Cтатус</label>
        <input type="text" id="status" name="status" required>

        <label for="notes">Заметки</label>
        <input type="text" id="notes" name="notes">

        <label for="id_order">ID заказа</label>
        <input type="text" id="id_order" name="id_order" required>

        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>
