#include <stdio.h>
#include <stdlib.h>
#include "findunit.h"

int main(int argc, char **argv)
{
	//int z=4;
	int r_m=0;
	int a[] = {1,2,3,0,5,6,7,8,9,8};
	int s = sizeof(a)/sizeof(a[0]);
	int* r = (int*)malloc(sizeof(int));
	//printf("%d", s);
	//printf("%d\n",line_find_one(a,s,*func));
	r_m = line_find_all(a,s,*func,r,r_m);
	printf("kolichestvo elementov = %d\n",r_m);
	for (int i=0;i<r_m;i++)
		printf("%d\n", r[i]);
	free(r);
	return 0;
}

