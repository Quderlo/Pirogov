<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial_number = $_POST['serial_number'];
    $name = $_POST['name'];
    $count = $_POST['count'];
    $id_client = $_POST['id_client'];

    $query = "INSERT INTO public.client_tech (serial_number, name, count, id_client) VALUES ('$serial_number', '$name', '$count', '$id_client')";
    $result = pg_query($conn, $query);
    if ($result) {
        echo "Техника успешно добавлена.";
    } else {
        echo "Ошибка: " . pg_last_error($conn); 
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление техники</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='tech_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить технику в таблицу</h2>
    <form method="post">
        <label for="serial_number">Серийный номер</label>
        <input type="text" id="serial_number" name="serial_number" required>

        <label for="name">Название</label>
        <input type="text" id="name" name="name" required>

        <label for="count">Кол-во</label>
        <input type="text" id="count" name="count" required>

        <label for="id_client">ID клиента</label>
        <input type="text" id="id_client" name="id_client" required>

        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>
