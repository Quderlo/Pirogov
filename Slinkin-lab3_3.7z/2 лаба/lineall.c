#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int z = 100125;

int func_line (int x) {
	return (x==z);
}

int main(int argc, char **argv)
{
	int s, r_m, n;
	scanf("%d", &n);
	int a[n];
	for (int i = 0; i<n; i++) {
		scanf("%d", &a[i]);
	}
	//int a[] = {0,1,2,3,4,5,6,7,8,8};
	//int a[] = {8,8,8,8,8,0,1,2,3,4};
	//int a[] = {8,8,8,8,8,8,8,8,8,8};
	s = sizeof(a)/sizeof(a[0]);
	//int* r = (int*)malloc(s * sizeof(int));
	r_m = 5;
	int* r = (int*)malloc(s * sizeof(int));
	int kol = line_find_all(a,s,func_line,r,r_m);
	printf("kolichestvo elementov = %d\n",kol);
	printf("index:\n");
	for (int i=0;i<kol;i++)
		printf("%d\n", r[i]);
	free(r);
	return 0;
}

