#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int find_count;

typedef int (*testfunc)(int);

int line_find_one(const int src[], int src_size, testfunc func) 
{
	find_count=0;
	for (int i=0;i<src_size;i++) {
		find_count++;
		if (func(src[i])) {
			printf("kolichestvo iterazhiy poiska = %d\n", find_count);
			return i;
		}
	}
   	return -1;
}

int line_find_all(const int src[], int src_size,  testfunc func, 
			      int result[], int result_maxsize)
{
	find_count=0;
	int j = 0;
	for(int i=0;i<src_size;i++){
		find_count++;
		if (result_maxsize>j || result_maxsize==0) {
			if(func(src[i])) {
				result[j] = i;	
				j++;
			}
		}
		else
			break;
	}
	printf("kolichestvo iterazhiy poiska = %d\n", find_count);
	return j;
}      
			 
int bin_find_one(const int src[], int src_size, testfunc func) 
{
	find_count=0;
	int center,ind;
	int left = 0;
	int right = src_size-1;
	while (left<=right) {
		find_count++;
		center = (left+right)/2;
		ind = func(src[center]);
		if (ind == 0) {
			printf("kolichestvo iterazhiy poiska = %d\n", find_count);
			return center;
		}
		else if (ind == 1) 
			left = center+1;
		else
			right = center -1;
	}
   	return -1;
}
 
int bin_find_all(const int src[], int src_size, testfunc func,
			      int *res_beg, int *res_end) 
{
	find_count=0;
	int center,ind;
	int left = 0;
	int right = src_size-1;
	ind = -2;
	while (left<=right) {
		find_count++;
		center = (left+right)/2;
		ind = func(src[center]);
		if (ind == 0) {
			*res_beg = *res_end = center;
			break;
		}
		else if (ind == 1) 
			left = center+1;
		else
			right = center -1;
		//printf("ind = %d\n", ind);
	}
	if (!ind) {
		while (center<=right) {
			find_count++;
			center++;
			ind = func(src[center]);
			if (ind == 0) {
				*res_end = center;
			}
			else if (ind == -1) 
				break;
		}
		center = *res_beg;
		while (center>=left) {
			find_count++;
			center--;
			ind = func(src[center]);
			if (ind == 0) {
				*res_end = center;
			}
			else if (ind == 1) 
				break;
		}
	}
	printf("kolichestvo iterazhiy poiska = %d\n", find_count);
   	return 0;
}

