<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $total_cost = $_POST['total_cost'];
    $created_at = date('Y-m-d H:i:s');
    $client_id = $_POST['client_id'];
    $worker_id = $_POST['worker_id'];

    
    $query = "INSERT INTO public.order (description, total_cost, created_at, client_id, worker_id) VALUES ('$description', '$total_cost', '$created_at', '$client_id', '$worker_id')";
    $result = pg_query($conn, $query);
    if ($result) {
        echo "Заказ успешно добавлен.";
    } else {
        echo "Ошибка!";
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление заказа</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='order_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить заказ в таблицу</h2>
    <form method="post">
        <label for="description">Описание заказа</label>
        <input type="text" id="description" name="description" required>

        <label for="total_cost">Общая стоимость</label>
        <input type="number" id="total_cost" name="total_cost" required>

        <label for="client_id">ID клиента</label>
        <input type="number" id="client_id" name="client_id" required>

        <label for="worker_id">ID работника</label>
        <input type="number" id="worker_id" name="worker_id" required>
        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>
