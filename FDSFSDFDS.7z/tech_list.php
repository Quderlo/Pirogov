<?php
error_reporting(E_ALL);


    $host = "localhost";
    $port = "5432";
    $dbname = "lev";
    $user = "postgres";
    $password = "";

    $conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    if (!$conn) {
        die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
    }
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title> Меню </title>
</head>


<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='tech_add.php'" class="head">Добавление новой техники</button>
    </div>

    <div class="content">
    <?php
        $res = pg_query($conn, "SELECT id, serial_number, name, count, id_client FROM public.client_tech");
        while ($row = pg_fetch_row($res)) {
            print'<div>';
                echo "id: ".$row[0].", Серийный номер: ".$row[1].", Название: ".$row[2].", Кол-во: ".$row[3].", ID клиента ".$row[4]."\n";
            print'</div>';
        }
    
        pg_close($conn);
    ?>
    </div>

</body>
</html>


