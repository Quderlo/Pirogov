#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int z = 100125;

int func_bin (int x) {
	if (x==z) return 0;
	if (x<z) return 1;
	else return -1; 
}

int main(int argc, char **argv)
{
	int r_b, r_e, n;
	scanf("%d", &n);
	int a[n];
	for (int i = 0; i<n; i++) {
		scanf("%d", &a[i]);
	}
	r_b=r_e=-1;
	//int a[] = {0,1,2,3,4,5,6,7,8,8,8,9};
	//int a[] = {0,1,2,3,4,5,6,7,9};
	int s = sizeof(a)/sizeof(a[0]);
	bin_find_all(a,s,func_bin,&r_b,&r_e);
	printf("perviy element = %d, posledniy element = %d\n", r_b, r_e);
	return 0;
}

