#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char **argv)
{
	int n;
	FILE *mf;
	srand (time(NULL));
	//printf("Vvedite n:");
	//scanf("%d", &n);
	n = 100000;
	int a[n];
	mf=fopen ("arr.txt","w");
	fprintf(mf, "%d\n", n);
	a[0] = 0;
	fprintf(mf, "%d\n", a[0]);
	for (int i = 1; i<n; i++) {
		a[i] = a[i-1] + rand() % 3;
		fprintf(mf, "%d\n", a[i]);
	}
	fclose(mf);
	return 0;
}

