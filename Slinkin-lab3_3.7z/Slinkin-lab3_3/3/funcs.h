#include "funcs.c"

int testbitF(unsigned long long A, int B);

int maxF(int A, int B, int C);

int squarenumF(int A, int B, int C);
