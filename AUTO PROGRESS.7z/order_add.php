<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}

//TODO: Сделать выбор воркера
$workers = array();
$query = "SELECT worker FROM public.directory";
$result = pg_query($conn, $query);
if ($result) {
    while ($row = pg_fetch_assoc($result)) {
        $types[$row['type']] = $row['type'];
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $total_cost = $_POST['total_cost'];
    $created_at = date('Y-m-d H:i:s');
    $client_id = (int)$_POST['client_id'];
    $worker_id = (int)$_POST['worker_id'];
    $serial_number = $_POST['serial_number'];
    $directory_id = $_POST['directory_id'];

    
    $query = "INSERT INTO public.order (description, total_cost, created_at, client_id, worker_id, serial_number, directory_id) 
    VALUES ('$description', '$total_cost', '$created_at', $client_id, $worker_id, '$serial_number', '$directory_id')";
    $result_order = pg_query($conn, $query);
    if ($result_order) {
        echo "Заказ успешно добавлен.";
    } else {
        echo "Ошибка!";
        echo pg_last_error();
    }


    // Автоматическое добавление статуса для заказа
    $query = "SELECT id FROM public.order where serial_number = '$serial_number' and client_id = $client_id";
    $result_search = pg_query($conn, $query);
    if ($result_search) {
        echo "Поиск выполнен.";
        $id_order = pg_fetch_assoc($result_search);
    } else {
        echo "Ошибка в поиске!";
        echo pg_last_error();
    }
    echo "$result_search";

    $query = "INSERT INTO public.progress (status, notes, id_order) VALUES ('В ожидании', 'Ждёт принятия в работу', '".$id_order['id']."')";
    $result_prog = pg_query($conn, $query);
    if ($result_prog) {
        echo "Статус добавлен.";
    } else {
        echo "Ошибка в статусе!";
        echo pg_last_error();
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление заказа</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='order_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить заказ в таблицу</h2>
    <form method="post">

        <label for="description">Описание заказа</label>
        <input type="text" id="description" name="description" required>

        <label for="total_cost">Общая стоимость</label>
        <input type="number" id="total_cost" name="total_cost" required>

        <label for="client_id">ID клиента</label>
        <input type="number" id="client_id" name="client_id" required>

        <label for="worker_id">ID работника</label>
        <input type="number" id="worker_id" name="worker_id">

        <label for="serial_number">Серийный номер</label>
        <input type="text" id="serial_number" name="serial_number" required>

        <label for="directory_id">ID Техники</label>
        <input type="text" id="directory_id" name="directory_id" required>

        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>