<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}


?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Меню</title>
</head>
<body>
    <div class="page-header">
    <h2><a class="header" href="menu.php">Компастер</a></h2>
    </div>

    <div class="actions">
        <div><a href="worker_list.php"> Лист работников</a> </div>
    </div>
</body>
</html>
