#ifndef _LOGS_
#define _LOGS_ 1
char lastcall[100] = "none";
#endif
