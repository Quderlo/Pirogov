<?php
error_reporting(E_ALL);


    $host = "localhost";
    $port = "5432";
    $dbname = "lev";
    $user = "postgres";
    $password = "123";

    $conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    if (!$conn) {
        die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
    }


    $workers = array();
    $query = "SELECT id, first_name, second_name FROM public.worker";
    $result = pg_query($conn, $query);
    if ($result) {
        while ($row = pg_fetch_assoc($result)) {
            $workers[$row['id']] = array($row['first_name'], $row['second_name']);
        }
    }

?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title> Меню </title>
</head>

<body>
    <div class="page-header">
        <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    </div>

    <div class="content">
    <h2></h2>
    <form method="post">
        <label for="worker">Работник:</label>
        <select name="worker" id="worker">
        <?php
        foreach ($workers as $id => $name) {
            echo "<option value=\"" . $id . "\">" . $name[0] . " " . $name[1] . "</option>";
        }
  ?>
</select>
<input type="submit" value="Отправить">
    </form>
    </div>
</body>
</html>

