<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}

$types = array();
$query = "SELECT DISTINCT type FROM public.directory";
$result = pg_query($conn, $query);
if ($result) {
    while ($row = pg_fetch_assoc($result)) {
        $types[$row['type']] = $row['type'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $type = isset($_POST['type']) ? $_POST['type'] : "";

    if ($type == "other" && isset($_POST['other_type'])) {
        // пользователь указал свой вариант типа
        $type = $_POST['other_type'];
    }


    $query = "INSERT INTO public.directory (name, type) VALUES ('$name', '$type')";
    $result = pg_query($conn, $query);
    if ($result) {
        echo "Техника успешно добавлена.";
    } else {
        echo "Ошибка: " . pg_last_error($conn); 
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление техники</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='tech_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить технику в таблицу</h2>
    <form method="post">
        <label for="name">Название</label>
        <input type="text" id="name" name="name" required>

        <label for="type">Тип</label>
        <select id="type" name="type" required>
            <?php foreach($types as $key => $value) { ?>
                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
            <?php } ?>
            <option value="other">Другое</option>
        </select>

        <input type="text" id="other_type" name="other_type">


        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>
