<?php
error_reporting(E_ALL);

$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}

if (isset($_GET['id'])) {
    $id_order = $_GET['id'];
    $query = "SELECT id, status, notes, id_order FROM public.progress WHERE id_order='$id_order'";
} else {
    $query = "SELECT id, status, notes, id_order FROM public.progress";
}

if(isset($_POST['status'])){
    $status = $_POST['status'];
    $notes = $_POST['notes'];
    $id_order = $_POST['id_order'];
    $result = pg_query($conn, "INSERT INTO public.progress (status, notes, id_order) VALUES ('$status', '$notes', '$id_order')");
    if (!$result) {
        echo "Произошла ошибка при выполнении запроса!";
    }
}

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title> Меню </title>
</head>


<body>
<div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='search.php'" class="head">Вернуться к поиску</button>
</div>

<div class="content">
    <?php
    $res = pg_query($conn, $query);

    while ($row = pg_fetch_assoc($res)) {
        print '<div>';
        echo "id: " . $row['id'] . ", Статус: " . $row['status'] . ", Заметки: " . $row['notes'] . ", ID заказа " . $row['id_order'] . "\n";
        print '</div>';
    }

    pg_close($conn);
    ?>
    <form method="POST" action="">
        <label>Статус:</label>
        <select id="status" name="status" required>
            <option value="Принято в работу">Принято в работу</option>
            <option value="В процессе">В процессе</option>
            <option value="Готов к выдаче">Готов к выдаче</option>
            <option value="Завершено">Завершено</option>
        </select>

        <br><br>

        <label>Заметки:</label>
        <input type="text" name="notes" required>

        <br><br>

        <input type="hidden" name="id_order" value="<?php echo $_GET['id']; ?>">
        <input type="submit" value="Добавить статус">
    </form>

</div>

</body>
</html>