#include <stdio.h>
#include <stdlib.h>
int z,s,k,i,j;
int* result; 
char testf(int x) 
{
    return (x==z);
}

int findone(int *arr)
{
   	for (i=0;i<s;i++)
   	if (testf(arr[i]))
		return i;
   	return -1;
}

void findmulti(int *arr) {
   	 //result=NULL;
   	 for (i=0;i<s;i++)
   	   if (testf(arr[i])) {
   	    //setlength(result,length(result)+1);
   	    //result[length(result)-1]:=i; 
   	    result = realloc(result,k);
	    result[k] = i;
	    k++;
   	   }
}

int main(int argc, char **argv)
{
	z=4;
	k=0;
	int a[] = {1,2,3,4,5,6,7,8,9,4};
	s = sizeof(a)/sizeof(a[0]);
	//printf("%d", s);
	//printf("%d\n",findone(a));
	findmulti(a);
	for (i=0;i<k;i++)
		printf("%d\n", result[i]);
	return 0;
}

