#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int find_count;

typedef int (*testfunc)(int);

int func (int x) {
	return (x==8);
}

int line_find_one(const int src[], int src_size, testfunc func) 
{
	find_count=1;
	for (int i=0;i<src_size;i++)
   	if (func(src[i]))
		return i;
   	return -1;
}


int line_find_all(const int src[], int src_size,  testfunc func, 
			      int result[], int result_maxsize)
{
	find_count=0;
	for(int i=0;i<src_size;i++){
		if(func(src[i])){
			result_maxsize++;
			if (result_maxsize!=1)
				result = realloc(result,result_maxsize  * sizeof(int));
			result[result_maxsize-1] = src[i];
			find_count++;	
		}
	}
	if (result_maxsize>0) 
		return result_maxsize;
	return 0;
}      
			
/*
 Бинарный поиск одного элемента в целочисленном массиве
 возвращает индекс найденного значения или -1
 Параметры:
 src - исходный массив
 src_size - кол-во элементов в src
 func - тест-функция
*/  
int bin_find_one(const int src[], int src_size, testfunc func);

/*
 Бинарный поиск всех элементов в целочисленном массиве
 возвращает количество найденных элементов или 0
 Параметры:
 src - исходный массив
 src_size - кол-во элементов в src
 func - тест-функция
 res_beg - адрес переменной, куда будет сохранен индекс первого найденного элемента
 res_end - адрес переменной, куда будет сохранен индекс последнего найденного элемента
*/  
int bin_find_all(const int src[], int src_size, testfunc func,
			      int *res_beg, int *res_end);

