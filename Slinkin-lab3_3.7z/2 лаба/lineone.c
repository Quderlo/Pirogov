#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int z = 100;

int func_line (int x) {
	return (x==z);
}

int main(int argc, char **argv)
{
	int a[] = {0,1,2,3,4,5,6,7,8,9};
	int s = sizeof(a)/sizeof(a[0]);
	printf("index: %d\n",line_find_one(a,s,func_line));
	//printf("%d", find_count);
	return 0;
}

