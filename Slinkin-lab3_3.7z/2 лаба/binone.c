#include "findunit.h"
#include <stdio.h>
#include <stdlib.h>

int z = 4;

int func_bin (int x) {
	if (x==z) return 0;
	if (x<z) return 1;
	else return -1; 
}

int main(int argc, char **argv)
{
	int a[] = {0,1,2,3,5,6,7,8,9};
	int s = sizeof(a)/sizeof(a[0]);
	printf("index: %d\n",bin_find_one(a,s,func_bin));
	return 0;
}

