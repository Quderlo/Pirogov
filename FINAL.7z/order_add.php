<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}

    //Массив уже готовых клиентов
    $techs = array();
    $query = "SELECT id, name, type FROM public.directory";
    $result = pg_query($conn, $query);
    if ($result) {
        while ($row = pg_fetch_assoc($result)) {
            $techs[$row['id']] = array($row['name'], $row['type']);
        }
    }

    //Массив уже готовых клиентов
    $clients = array();
    $query = "SELECT id, first_name, second_name FROM public.client";
    $result = pg_query($conn, $query);
    if ($result) {
        while ($row = pg_fetch_assoc($result)) {
            $clients[$row['id']] = array($row['first_name'], $row['second_name']);
        }
}

    //Массив уже готовых работников
    $workers = array();
    $query = "SELECT id, first_name, second_name FROM public.worker";
    $result = pg_query($conn, $query);
    if ($result) {
        while ($row = pg_fetch_assoc($result)) {
            $workers[$row['id']] = array($row['first_name'], $row['second_name']);
        }
    }


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $created_at = date('Y-m-d H:i:s');


    //Проверка на то что пользователь ввёл нового клиента
    $client = isset($_POST['client']) ? $_POST['client'] : '';
    if ($client == 'new') { //Если новый
        $newFirstName = isset($_POST['new_first_name']) ? $_POST['new_first_name'] : '';
        $newSecondName = isset($_POST['new_second_name']) ? $_POST['new_second_name'] : '';
        $newTelephone = isset($_POST['new_telephone']) ? $_POST['new_telephone'] : '';
        $newAdress = isset($_POST['new_adress']) ? $_POST['new_adress'] : '';

        $query = "INSERT INTO public.client(first_name, second_name, adress, telephone, created_at) 
        VALUES('$newFirstName', '$newSecondName', ' $newAdress', '$newTelephone', '$created_at')";
        $result_client = pg_query($conn, $query);
        if ($result_client) {
        echo "Клиент успешно добавлен.";
        } else {
                echo "Ошибка!";
                echo pg_last_error();
            }

        $query = "SELECT id FROM public.client where first_name = '$newFirstName' and second_name = '$newSecondName'";
        $result_search = pg_query($conn, $query);
        if ($result_search) {
        echo "Поиск клиента выполнен.";
        $client_id = pg_fetch_assoc($result_search)['id'];
        } else {
        echo "Ошибка в поиске клиента!";
        echo pg_last_error();
        }
        

    } else $client_id = (int)$_POST['client']; //Если уже существует

    //Проверка на то что пользователь ввёл новую технику
    $tech = isset($_POST['tech']) ? $_POST['tech'] : '';
    if ($tech == 'new') { //Если новая
        $newName = isset($_POST['new_name']) ? $_POST['new_name'] : '';
        $newType = isset($_POST['new_type']) ? $_POST['new_type'] : '';

        $query = "INSERT INTO public.directory(name, type) VALUES('$newName', '$newType')";
        $result_tech = pg_query($conn, $query);
        if ($result_tech) {
        echo "Техника успешно добавлен.";
        } else {
                echo "Ошибка!";
                echo pg_last_error();
            }

        $query = "SELECT id FROM public.directory where name = '$newName' and type = '$newType'";
        $result_search = pg_query($conn, $query);
        if ($result_search) {
        echo "Поиск техники выполнен.";
        $directory_id = pg_fetch_assoc($result_search)['id'];
        } else {
        echo "Ошибка в поиске клиента!";
        echo pg_last_error();
        }
        

    } else $directory_id = (int)$_POST['tech']; //Если уже существует

    $description = $_POST['description'];
    $total_cost = $_POST['total_cost'];
    $worker_id = (int)$_POST['worker'];
    $serial_number = $_POST['serial_number'];


    //Добавление заказа
    $query = "INSERT INTO public.order (description, total_cost, created_at, client_id, worker_id, serial_number, directory_id) 
    VALUES ('$description', '$total_cost', '$created_at', $client_id, $worker_id, '$serial_number', '$directory_id')";
    $result_order = pg_query($conn, $query);
    if ($result_order) {
        echo "Заказ успешно добавлен.";
    } else {
        echo "Ошибка!";
        echo pg_last_error();
    }


    // Автоматическое добавление статуса для заказа
    $query = "SELECT id FROM public.order where serial_number = '$serial_number' and client_id = $client_id";
    $result_search = pg_query($conn, $query);
    if ($result_search) {
        echo "Поиск заказа выполнен.";
        $id_order = pg_fetch_assoc($result_search);
    } else {
        echo "Ошибка в поиске заказа!";
        echo pg_last_error();
    }

    $query = "INSERT INTO public.progress (status, notes, id_order) VALUES ('В ожидании', 'Ждёт принятия в работу', '".$id_order['id']."')";
    $result_prog = pg_query($conn, $query);
    if ($result_prog) {
        echo "Статус добавлен.";
    } else {
        echo "Ошибка в статусе!";
        echo pg_last_error();
    }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление заказа</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='order_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить заказ в таблицу</h2>
    <form method="post">
        <div class="input_main">
            <label for="description">Описание заказа</label>
            <input type="text" id="description" name="description" required>

            <label for="total_cost">Общая стоимость</label>
            <input type="number" id="total_cost" name="total_cost" required>

            <label for="serial_number">Серийный номер</label>
            <input type="text" id="serial_number" name="serial_number" required>
        </div>

        <div class="input_tech">
            <label for="tech">Техника:</label>
            <select name="tech" id="tech" multiple required>
                <option value="new">Новая</option>
            <?php //Вывод уже готовых клиентов
                foreach ($techs as $id => $name) {
                    echo "<option value=\"" . $id . "\">" . $name[0] . " " . $name[1] . "</option>";
                }
            ?>
            </select>

            <label for="new_name">Название техники:</label>
            <input type="text" id="new_name" name="new_name">
            <label for="new_type">Категория:</label>
            <input type="text" id="new_type" name="new_type">
            
        </div>

        <div class="input_client">
            <label for="client">Клиент:</label>
            <select name="client" id="client" multiple required>
                <option value="new">Новый</option>
            <?php //Вывод уже готовых клиентов
                foreach ($clients as $id => $name) {
                    echo "<option value=\"" . $id . "\">" . $name[0] . " " . $name[1] . "</option>";
                }
            ?>
            </select>
            <label for="new_first_name">Имя:</label>
            <input type="text" id="new_first_name" name="new_first_name">
            <label for="new_second_name">Фамилия:</label>
            <input type="text" id="new_second_name" name="new_second_name">
            <label for="new_telephone">Телефон:</label>
            <input type="text" id="new_telephone" name="new_telephone">
            <label for="new_adress">Адрес:</label>
            <input type="text" id="new_adress" name="new_adress">
            
        </div>
        
        <div class="input_worker">
            <label for="worker">Работник:</label>
            <select name="worker" id="worker" required>
            <?php //Вывод уже готовых Работников
                foreach ($workers as $id => $name) {
                    echo "<option value=\"" . $id . "\">" . $name[0] . " " . $name[1] . "</option>";
                }
            ?>
            </select>
        </div>
            <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>