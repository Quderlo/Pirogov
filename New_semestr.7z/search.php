<?php
error_reporting(E_ALL);

$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";


if (isset($_POST['search_query']) && !empty($_POST['search_query'])) {

    $conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    if (!$conn) {
        die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
    }

    $search_query = $_POST['search_query'];

    // Поиск по имени и фамилии клиента
    $result = pg_query_params($conn,
        'SELECT o.id, o.description, o.total_cost, o.serial_number, o.created_at, d.type, d.name, c.first_name, c.second_name, w.first_name AS worker_first_name, w.second_name AS worker_second_name 
         FROM public."order" o 
         JOIN public."directory" d ON o.directory_id = d.id 
         JOIN public."client" c ON o.client_id = c.id 
         JOIN public."worker" w ON o.worker_id = w.id 
         WHERE c.first_name ILIKE $1 OR c.second_name ILIKE $1',
        array("%$search_query%"));

    // ID заказа
    if (pg_num_rows($result) == 0 && is_numeric($search_query)) {
        $result = pg_query_params($conn,
            'SELECT o.id, o.description, o.total_cost, o.serial_number, o.created_at, d.type, d.name, c.first_name, c.second_name, w.first_name AS worker_first_name, w.second_name AS worker_second_name 
             FROM public."order" o 
             JOIN public."directory" d ON o.directory_id = d.id 
             JOIN public."client" c ON o.client_id = c.id 
             JOIN public."worker" w ON o.worker_id = w.id 
             WHERE o.id = $1',
            array($search_query));
    }

    // Фамилия работника
    if (pg_num_rows($result) == 0) {
        $result = pg_query_params($conn,
            'SELECT o.id, o.description, o.total_cost, o.serial_number, o.created_at, d.type, d.name, c.first_name, c.second_name, w.first_name AS worker_first_name, w.second_name AS worker_second_name 
             FROM public."order" o 
             JOIN public."directory" d ON o.directory_id = d.id 
             JOIN public."client" c ON o.client_id = c.id 
             JOIN public."worker" w ON o.worker_id = w.id 
             WHERE w.first_name ILIKE $1 OR w.second_name ILIKE $1',
            array("%$search_query%"));
    }

    pg_close($conn);

} else {
    $search_query = '';
    $result = null;
}

?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title> Поиск заказов </title>
</head>

<body>
    <div class="page-header">
        <h2 class="menu"><a class="header" href="main_menu.php">Компастер</a></h2>
        <button onclick="window.location.href='main_menu.php'" class="head">Вернуться в меню</button>
    </div>

    <div class="content">
        <form method="POST">
            <label for="search_query">Введите имя и фамилию клиента или ID заказа или имя и фамилию работника:</label>
            <input type="text" id="search_query" name="search_query" value="<?= htmlspecialchars($search_query) ?>">
            <input type="submit" value="Искать">
        </form>

        <?php if ($result !== null): ?>
            <?php if (pg_num_rows($result) > 0): ?>
                <h3>Результат поиска:</h3>
                <table>
                    <tr>
                        <th>№ заказа</th>
                        <th>Описание</th>
                        <th>Серийный номер</th>
                        <th>Цена</th>
                        <th>Дата создания</th>
                        <th>Тип техники</th>
                        <th>Название техники</th>
                        <th>Имя клиента</th>
                        <th>Фамилия клиента</th>
                        <th>Имя работника</th>
                        <th>Фамилия работника</th>
                    </tr>
                    <?php while ($row = pg_fetch_assoc($result)): ?>
                        <tr>
                            <td><a href="order_progress.php?id=<?= $row['id'] ?>"><?= $row['id'] ?></a></td>
                            <td><?= $row['description'] ?></td>
                            <td><?= $row['serial_number'] ?></td>
                            <td><?= $row['total_cost'] ?></td>
                            <td><?= $row['created_at'] ?></td>
                            <td><?= $row['type'] ?></td>
                            <td><?= $row['name'] ?></td>
                            <td><?= $row['first_name'] ?></td>
                            <td><?= $row['second_name'] ?></td>
                            <td><?= $row['worker_first_name'] ?></td>
                            <td><?= $row['worker_second_name'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>Ничего не найдено.</p>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</body>
</html>