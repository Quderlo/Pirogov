<?php
// код для подключения к базе данных
$host = "localhost";
$port = "5432";
$dbname = "lev";
$user = "postgres";
$password = "123";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Ошибка: Не удалось подключиться к базе данных (pg_connect)!");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $second_name = $_POST['second_name'];
    $address = $_POST['adress'];
    $telephone = $_POST['telephone'];
    $created_at = date("Y-m-d H:i:s");
 
    $query = "INSERT INTO public.client (first_name, second_name, adress, telephone, created_at) 
    VALUES ('$first_name', '$second_name', '$address', '$telephone', '$created_at')";
    $result = pg_query($conn, $query);
    if ($result) {   
        echo "Клиент успешно добавлен.";    
     } else {   
        echo "Ошибка!"; 
     }

    // закрываем соединение с базой
    pg_close($conn);
}
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Добавление клиента</title>
</head>
<body>
    <div class="page-header">
    <h2 class="menu"><a class="header" href="menu.php">Компастер</a></h2>
    <button onclick="window.location.href='client_list.php'" class="head">Возвращение к списку</button>
    </div>

    <div class="content">
    <h2>Добавить клиента в таблицу</h2>
    <form method="post">
        <label for="first_name">Имя</label>
        <input type="text" id="first_name" name="first_name" required>

        <label for="second_name">Фамилия</label>
        <input type="text" id="second_name" name="second_name" required>

        <label for="adress">Адрес</label>
        <input type="text" id="adress" name="adress" required>

        <label for="telephone">Телефон</label>
        <input type="text" id="telephone" name="telephone" required>


        <input type="submit" value="Добавить">
    </form>
    </div>
</body>
</html>
