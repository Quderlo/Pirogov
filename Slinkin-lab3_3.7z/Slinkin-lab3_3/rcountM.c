#include <stdio.h>
#include <string.h>

#define rcountM(A, result) {\
for (int i = 0; A[i] != '\0'; i++) {\
    if (((unsigned char)A[i] == 0xd0) && (((unsigned char)A[i + 1] == 0x81) || (((unsigned char)A[i] >= 0x90) && ((unsigned char)A[i + 1] <= 0xbf)))) \
		result++;\
	if (((unsigned char)A[i] == 0xd1) && (((unsigned char)A[i + 1] == 0x91) || (((unsigned char)A[i] >= 0x80) && ((unsigned char)A[i + 1] <= 0xbf))))\
		result++;\
    }\
}

int main() {
    unsigned short result = 0;
    char A[100];

    fgets(A, 100, stdin);
    
    A[strlen(A)-1] = '\0';
    rcountM(A, result);
    printf("букв: %hu\n", result);

}//Ћ
